﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Net.Cache;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp2.model;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ApplicationContext db = new ApplicationContext();
        public MainWindow()
        {
            InitializeComponent();

            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            db.Database.EnsureCreated();
            db.Users.Load();
            DataContext = db.Users.Local.ToObservableCollection();

        }

        private void add_click(object sender, RoutedEventArgs e) 
        {
            UserWindow userWindow = new UserWindow(new model.User());
            if (userWindow.ShowDialog() == true ) 
            {
                model.User User = userWindow.User;
                db.Users.Add(User);
                db.SaveChanges();
            }
        }

        private void delet_click(object sender, RoutedEventArgs e)
        {
            UserWindow userWindow = new UserWindow(new model.User());
            User? user = UserList.SelectedItem as User;
            if (user == null) return;
                db.Users.Remove(user);
                db.SaveChanges();
            
        }

    }    
}